package com.api.model;

import static javax.persistence.GenerationType.IDENTITY;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;


@Entity
@Table(name = "subdistrict2011_bound", uniqueConstraints = {
		@UniqueConstraint(columnNames = "sdtcode11")})
public class NationalTaluka {

	private int gid;
	private String stateId;
	private String distId;
	private String subdistId;
	private String subdistName;
	private Double minx;
	private Double miny;
	private Double maxx;
	private Double maxy;
	//private String geom;
	
		
	@Column(name = "gid", unique = true, nullable = false)
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	
	
	@Column(name = "stcode11")
	public String getStateId() {
		return stateId;
	}
	public void setStateId(String stateId) {
		this.stateId = stateId;
	}
	
	@Column(name = "dtcode11")
	public String getDistId() {
		return distId;
	}
	public void setDistId(String distId) {
		this.distId = distId;
	}
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "sdtcode11", unique = true, nullable = false)
	public String getSubdistId() {
		return subdistId;
	}
	public void setSubdistId(String subdistId) {
		this.subdistId = subdistId;
	}
	
	@Column(name = "name11")
	public String getSubdistName() {
		return subdistName;
	}
	public void setSubdistName(String subdistName) {
		this.subdistName = subdistName;
	}
	
	
	@Column(name = "minx", nullable = false)
	public Double getMinx() {
		return minx;
	}
	public void setMinx(Double minx) {
		this.minx = minx;
	}
	
	@Column(name = "miny", nullable = false)
	public Double getMiny() {
		return miny;
	}
	public void setMiny(Double miny) {
		this.miny = miny;
	}
	
	@Column(name = "maxx", nullable = false)
	public Double getMaxx() {
		return maxx;
	}
	public void setMaxx(Double maxx) {
		this.maxx = maxx;
	}
	
	@Column(name = "maxy", nullable = false)
	public Double getMaxy() {
		return maxy;
	}
	public void setMaxy(Double maxy) {
		this.maxy = maxy;
	}
	
}