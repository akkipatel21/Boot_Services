package com.api.model;


import static javax.persistence.GenerationType.IDENTITY;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "state2014_bound", uniqueConstraints = {
		@UniqueConstraint(columnNames = "stcode11")})
public class StateBound {
	
	private int gid;
	private String stname;
	private String stcode11;
	private double minx;
	private double miny;
	private double maxx;
	private double maxy;
	
		
	@Column(name = "gid", unique = true, nullable = false)
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	@Column(name = "stname", nullable = false)
	public String getStname() {
		return stname;
	}
	public void setStname(String stname) {
		this.stname = stname;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "stcode11", unique = true, nullable = false)
	public String getStcode11() {
		return stcode11;
	}
	public void setStcode11(String stcode11) {
		this.stcode11 = stcode11;
	}
	@Column(name = "minx", nullable = false)
	public double getMinx() {
		return minx;
	}
	public void setMinx(double minx) {
		this.minx = minx;
	}
	@Column(name = "miny", nullable = false)
	public double getMiny() {
		return miny;
	}
	public void setMiny(double miny) {
		this.miny = miny;
	}
	@Column(name = "maxx", nullable = false)
	public double getMaxx() {
		return maxx;
	}
	public void setMaxx(double maxx) {
		this.maxx = maxx;
	}
	@Column(name = "maxy", nullable = false)
	public double getMaxy() {
		return maxy;
	}
	public void setMaxy(double maxy) {
		this.maxy = maxy;
	}
	
}
