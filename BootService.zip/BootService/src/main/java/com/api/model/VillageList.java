package com.api.model;

import static javax.persistence.GenerationType.IDENTITY;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;


@Entity
@Table(name = "village_bound", uniqueConstraints = {
		@UniqueConstraint(columnNames = "vil_2011")})
public class VillageList {

//	private int gid;
//	private String vilNameSoi;
//	private String stateId;
//	private String distId;
	private String subdistId;
	private String villageId;
	private String villageName;
	private Double minx;
	private Double miny;
	private Double maxx;
	private Double maxy;
	
	//private String geom;
	
/*	private Set<Location> location;*/
	
//	@Column(name = "gid", unique = true, nullable = false)
//	public int getGid() {
//		return gid;
//	}
//	public void setGid(int gid) {
//		this.gid = gid;
//	}
//	
//	
//	@Column(name = "vilnam_soi")
//	public String getVilNameSoi() {
//		return vilNameSoi;
//	}
//	public void setVilNameSoi(String vilNameSoi) {
//		this.vilNameSoi = vilNameSoi;
//	}
//	
//	@Column(name = "st_2011")
//	public String getStateId() {
//		return stateId;
//	}
//	public void setStateId(String stateId) {
//		this.stateId = stateId;
//	}
//	
//	@Column(name = "dt_2011")
//	public String getDistId() {
//		return distId;
//	}
//	public void setDistId(String distId) {
//		this.distId = distId;
//	}
//	
	@Column(name = "sdt_2011")
	public String getSubdistId() {
		return subdistId;
	}
	public void setSubdistId(String subdistId) {
		this.subdistId = subdistId;
	}
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "vil_2011", nullable = false)
	public String getVillageId() {
		return villageId;
	}
	public void setVillageId(String villageId) {
		this.villageId = villageId;
	}
	
	
	@Column(name = "vil_name11")
	public String getVillageName() {
		return villageName;
	}
	public void setVillageName(String villageName) {
		this.villageName = villageName;
	}
	@Column(name = "minx")
	public Double getMinx() {
		return minx;
	}
	public void setMinx(Double minx) {
		this.minx = minx;
	}
	@Column(name = "miny")
	public Double getMiny() {
		return miny;
	}
	public void setMiny(Double miny) {
		this.miny = miny;
	}
	@Column(name = "maxx", nullable = false)
	public Double getMaxx() {
		return maxx;
	}
	public void setMaxx(Double maxx) {
		this.maxx = maxx;
	}
	@Column(name = "maxy",nullable = false)
	public Double getMaxy() {
		return maxy;
	}
	public void setMaxy(Double maxy) {
		this.maxy = maxy;
	}
}
