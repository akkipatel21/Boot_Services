package com.api.model;

import static javax.persistence.GenerationType.IDENTITY;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "ndrf_gis_data_entry", uniqueConstraints = {
		@UniqueConstraint(columnNames = "id")})
public class NdrfGeom {

	private int id;
	
	private String st_id;
	private String stateName;
	private String dist_id;
	private String districtName;
	private String tal_id;	
	private String talukaName;
	private String vill_id;
	private String villageName;
	
////Ndrf data ///
	
	private String latitude_d ;
	private String longitude_d;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private String inc_st_date;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private String inc_st_time;
	private String inc_details;
	private String reporter_name;
	private String reporter_mblnum;
	
	private String createdDate;
	
	private String geom_type;
	@Transient
	private String addGeom;
	
	@Transient
	private int user_Id;
    //private UserLogin userlogin;
	
			
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	
	@Column(name="st_id")
	public String getSt_id() {
		return st_id;
	}
	public void setSt_id(String st_id) {
		this.st_id = st_id;
	}
	
	@Column(name="sname")
	public String getstateName() {
		return stateName;
	}
	public void setstateName(String sname) {
		this.stateName = sname;
	}
	
	@Column(name="dist_id")
	public String getDist_id() {
		return dist_id;
	}
	public void setDist_id(String dist_id) {
		this.dist_id = dist_id;
	}
	
	@Column(name="dname")
	public String getDistrictName() {
		return districtName;
	}
	public void setDistrictName(String dname) {
		this.districtName = dname;
	}
	
	@Column(name="tal_id")
	public String getTal_id() {
		return tal_id;
	}
	public void setTal_id(String tal_id) {
		this.tal_id = tal_id;
	}
	
	@Column(name="tname")
	public String getTalukaName() {
		return talukaName;
	}
	public void setTalukaName(String tname) {
		this.talukaName = tname;
	}
	
	@Column(name="vill_id")
	public String getVill_id() {
		return vill_id;
	}
	public void setVill_id(String vill_id) {
		this.vill_id = vill_id;
	}
	
	@Column(name="vname")
	public String getVillageName() {
		return villageName;
	}
	public void setVillageName(String vname) {
		this.villageName = vname;
	}
	
	
	@Column(name="date_latlon")
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	
	@Column(name="geom_type")
	public String getGeom_type() {
		return geom_type;
	}
	public void setGeom_type(String geom_type) {
		this.geom_type = geom_type;
	}
	
	//@Column(name="geom",nullable=true)
	@Transient
	public String getAddGeom() {
		return addGeom;
	}
	public void setAddGeom(String addGeom) {
		this.addGeom = addGeom;
	}
	
	@Transient
	public int getUser_Id() {
		return user_Id;
	}
	public void setUser_Id(int user_Id) {
		this.user_Id = user_Id;
	}
	
	
	
	
	///ndrf ///
	@Column(name="Latitude_d")
	
	public String getLatitude_d() {
		return latitude_d;
	}
	public void setLatitude_d(String latitude_d) {
		this.latitude_d = latitude_d;
	}
	
	
	@Column(name="Longitude_d")
	public String getLongitude_d() {
		return longitude_d;
	}
	public void setLongitude_d(String longitude_d) {
		this.longitude_d = longitude_d;
	}
	
	
	@Column(name="inc_st_date")
	public String getInc_st_date() {
		return inc_st_date;
	}
	public void setInc_st_date(String inc_st_date) {
		this.inc_st_date = inc_st_date;
	}
	
	@Column(name="inc_st_time")
	public String getInc_st_time() {
		return inc_st_time;
	}
	public void setInc_st_time(String inc_st_time) {
		this.inc_st_time = inc_st_time;
	}
	
	
	@Column(name="inc_details")
	public String getInc_details() {
		return inc_details;
	}
	public void setInc_details(String inc_details) {
		this.inc_details = inc_details;
	}
	
	@Column(name="reporter_name")
	public String getReporter_name() {
		return reporter_name;
	}
	public void setReporter_name(String reporter_name) {
		this.reporter_name = reporter_name;
	}
	
	@Column(name="reporter_mblnum")
	public String getReporter_mblnum() {
		return reporter_mblnum;
	}
	public void setReporter_mblnum(String reporter_mblnum) {
		this.reporter_mblnum = reporter_mblnum;
	}
	@Override
	public String toString() {
		return "NdrfGeom [id=" + id + ", st_id=" + st_id + ", stateName=" + stateName + ", dist_id=" + dist_id
				+ ", districtName=" + districtName + ", tal_id=" + tal_id + ", talukaName=" + talukaName + ", vill_id="
				+ vill_id + ", villageName=" + villageName + ", Latitude_d=" + latitude_d + ", Longitude_d="
				+ longitude_d + ", inc_st_date=" + inc_st_date + ", inc_st_time=" + inc_st_time + ", inc_details="
				+ inc_details + ", reporter_name=" + reporter_name + ", reporter_mblnum=" + reporter_mblnum
				+ ", createdDate=" + createdDate + ", geom_type=" + geom_type + ", addGeom=" + addGeom + ", user_Id="
				+ user_Id + "]";
	}
	
	
	
}
