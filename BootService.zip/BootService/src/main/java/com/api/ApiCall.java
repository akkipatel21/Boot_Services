package com.api;

import java.io.IOException;
import java.security.Key;
import java.util.Date;
import java.util.UUID;

import javax.crypto.spec.SecretKeySpec;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class ApiCall {

	public static void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		Cookie loginCookie = null;
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				if (cookie.getName().equals("jwt")) {
					loginCookie = cookie;
					break;
				}
			}
		}
		if (loginCookie != null) {
			loginCookie.setMaxAge(0);
			response.addCookie(loginCookie);
		}
		response.sendRedirect("login.html");
	}

	public static String callAPI(String callUrl) {

		String urlCall = callUrl + "rest/jwtSecurityReceive";

		String output = callGetApi(urlCall);

		return output;

	}

	private static String callGetApi(String urlCall) {

		long timeMillis = System.currentTimeMillis();

		String id = UUID.randomUUID().toString().replace("-", "");
		String jwtOutput = createJWT(id, "bisag", "updateData", timeMillis);

		System.out.println("jwtOutput::" + jwtOutput);
		String param = "{'jwtToken':'" + jwtOutput + "'}";
		return jwtOutput;
	}

//		try {
//			HttpHeaders headers = new HttpHeaders();
//			headers.setContentType(new MediaType("application","json",Charset.forName("UTF-8")));
//			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//			headers.setAcceptCharset(Arrays.asList(Charset.forName("UTF-8")));
//			HttpEntity<String> entity = new HttpEntity<String>(param,headers);
//			if(entity.hasBody()) {
//				
//			}
//			HttpHeaders httpHeaders = entity.getHeaders();
//			for(Entry<String, List<String>> obj :httpHeaders.entrySet() ) {
//				
//			}
//			
//			RestTemplate restTemplate = new RestTemplate();
//			restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(Charset.forName("UTF-8")));
//			List<HttpMessageConverter<?>> c = restTemplate.getMessageConverters();
//			for(HttpMessageConverter<?> mc : c) {
//				if(mc instanceof StringHttpMessageConverter) {
//					StringHttpMessageConverter mcc = (StringHttpMessageConverter) mc;
//					mcc.setWriteAcceptCharset(false);
//				}
//			}
//			
//			ResponseEntity<String> response = restTemplate.exchange(urlCall, HttpMethod.POST,entity,String.class);
//			
//			if(response.getStatusCode() == HttpStatus.OK) {
//				
//				/*System.out.println("response.getStatusCode()::"+response.getStatusCode());
//				System.out.println("response.getBody()::"+response.getBody().toString());*/
//				return response.getBody().toString();
//			}
//			return null;
//		} catch (Exception e) {
//			e.printStackTrace();
//			return null;
//		}
//	}

	private static String createJWT(String id, String issuer, String subject, long ttlMillis) {

		// The JWT signature algorithm we will be using to sign the token
		SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;

		long nowMillis = System.currentTimeMillis();
		Date now = new Date(nowMillis);

		// We will sign our JWT with our ApiKey secret
		@SuppressWarnings("restriction")

		final String secret = "JwtQwx@PeS!ense#22011992$MbPtl21";
		// final Key secret = MacProvider.generateKey(SignatureAlgorithm.HS256);
		// final byte[] secretBytes = secret.getEncoded();
		// final String base64SecretBytes =
		// Base64.getEncoder().encodeToString(secretBytes);

		byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(secret);
		Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());

		// Let's set the JWT Claims
		JwtBuilder builder = Jwts.builder().setId(id).setIssuedAt(now).setSubject(subject).setIssuer(issuer)
				.signWith(signatureAlgorithm, signingKey);
		// if it has been specified, let's add the expiration
		if (ttlMillis >= 0) {
			long expMillis = nowMillis + ttlMillis;
			Date exp = new Date(expMillis);
			builder.setExpiration(exp);
		}

		// Builds the JWT and serializes it to a compact, URL-safe string
		return builder.compact();
	}

}