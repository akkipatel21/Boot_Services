package com.api;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
@EnableWebMvc
@SpringBootApplication(scanBasePackages = {"com.api"})
@EnableJpaRepositories(basePackages = {"com.api.repo","com.api.crud.repo"})
public class SpringBootCrud2Application {

    @Value("${services.auth}")
    private String authService;

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCrud2Application.class, args);
	}

}
