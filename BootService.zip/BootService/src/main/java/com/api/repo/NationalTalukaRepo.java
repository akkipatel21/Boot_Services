package com.api.repo;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

import com.api.model.NationalTaluka;

public interface NationalTalukaRepo extends JpaRepository<NationalTaluka, String> {

	List<NationalTaluka> findByDistId(String distId);

	List<NationalTaluka> findByDistIdOrderBySubdistName(String distId);

}
