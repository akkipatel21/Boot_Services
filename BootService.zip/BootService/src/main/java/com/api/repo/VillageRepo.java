package com.api.repo;

import java.util.List;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.api.model.VillageList;

@Repository
public interface VillageRepo extends JpaRepository<VillageList, String> {

	
	List<VillageList> findBySubdistId(String subdistId);

	List<VillageList> findByVillageNameStartingWithIgnoreCaseOrderByVillageName(String villageName);

	List<VillageList> findBySubdistIdOrderByVillageName(String subdistId);
	
	}
