package com.api.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.api.model.StateBound;

@Repository
public interface StateBoundRepo extends JpaRepository<StateBound, String>{

	List<StateBound> findAllByOrderByStname();
}
