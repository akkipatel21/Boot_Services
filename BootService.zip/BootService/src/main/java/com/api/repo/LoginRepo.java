package com.api.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.api.model.Login;
@Transactional
public interface LoginRepo extends JpaRepository<Login, String> {
	
	@Query("SELECT count(l) FROM Login l WHERE l.passWord =:pwd AND l.userName=:uname")
	public int findbyparam(@Param("uname") String userName,@Param("pwd")String PassWord);

	public Login findByUserNameAndPassWord(String userName, String passWord);

	public Login findByUserIdAndToken(int userId, String token);

	public long countByUserNameAndPassWord(String userName, String password);

	public long countByToken(String token);
}