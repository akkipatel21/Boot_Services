package com.api.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.api.model.NationalDistrict;

public interface NationalDistrictRepo extends JpaRepository<NationalDistrict, String> {

	List<NationalDistrict> findByStateId(String stateId);

	List<NationalDistrict> findByStateIdOrderByDistName(String stateId);

}
