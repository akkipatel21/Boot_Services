package com.api.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.api.model.NdrfGeom;
import com.api.repo.NdrfRepo;

@Service
public class NdrfService {
	@Autowired
	NdrfRepo ndrfRepo; 
	
	public void save(NdrfGeom ndrfGeom) {
	ndrfRepo.save(ndrfGeom);
		
	}

	public List<NdrfGeom> findAll() {
		return ndrfRepo.findAll();
	}

}
