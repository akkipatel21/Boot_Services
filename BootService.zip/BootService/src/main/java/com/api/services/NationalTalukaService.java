package com.api.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.api.model.NationalTaluka;
import com.api.repo.NationalTalukaRepo;


@Service
public class NationalTalukaService {
	
	@Autowired
	NationalTalukaRepo natoNationalTalukaRepo;

	public List<NationalTaluka> findByDistId(String distId) {
		return natoNationalTalukaRepo.findByDistId(distId);
	}

	public List<NationalTaluka> findByDistIdOrderBySubdistName(String distId) {
		return natoNationalTalukaRepo.findByDistIdOrderBySubdistName(distId);
	}
	
	
	
}
