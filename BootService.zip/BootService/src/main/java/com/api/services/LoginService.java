package com.api.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.api.model.Login;
import com.api.repo.LoginRepo;


@Service
public class LoginService {

	@Autowired
	LoginRepo loginRepo;

	public int findbyparam(String userName, String passWord) {
		return loginRepo.findbyparam(userName,passWord);
	}

	public Login findByUserNameAndPassWord(String userName, String passWord) {
		return loginRepo.findByUserNameAndPassWord(userName,passWord);
	}

	public Login findByUserIdAndToken(int userId, String token) {
		return loginRepo.findByUserIdAndToken(userId,token);
	}
	
	
	
}
