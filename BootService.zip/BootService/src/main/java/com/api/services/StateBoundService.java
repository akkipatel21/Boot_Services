package com.api.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.api.model.StateBound;
import com.api.repo.StateBoundRepo;

@Service
public class StateBoundService {

	@Autowired
	StateBoundRepo stateBoundRepo;

	public List<StateBound> findAll() {
		return stateBoundRepo.findAll();
	}

	public List<StateBound> findAllByOrderByStname() {
		return stateBoundRepo.findAllByOrderByStname();
	}

	
	
	
}
