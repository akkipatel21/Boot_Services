package com.api.services;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.api.model.NationalDistrict;
import com.api.repo.NationalDistrictRepo;


@Service
public class NationalDistrictService {

	@Autowired
	NationalDistrictRepo nationalDistrictRepo;

	public List<NationalDistrict> findByStateId(String stateId) {
		return nationalDistrictRepo.findByStateId(stateId);
	}

	public List<NationalDistrict> findByStateIdOrderByDistName(String stateId) {
		
		return nationalDistrictRepo.findByStateIdOrderByDistName(stateId);
	}
	
}