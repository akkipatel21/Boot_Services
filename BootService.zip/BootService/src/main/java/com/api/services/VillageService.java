package com.api.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.api.model.VillageList;
import com.api.repo.VillageRepo;

@Service
public class VillageService {

	@Autowired
	VillageRepo villageRepo;


	public List<VillageList> findBySubdistId(String subdistId) {
		return villageRepo.findBySubdistId(subdistId);
	}

	public List<VillageList> findAll() {
		return villageRepo.findAll();
	}

//	public List<VillageList> findByPlaceContainingIgnoreCase(String villageName) {
//		return villageRepo.findByPlaceContainingIgnoreCase(villageName);
//	}

	public List<VillageList> findByVillageNameStartingWithIgnoreCaseOrderByVillageName(String villageName) {
		return villageRepo.findByVillageNameStartingWithIgnoreCaseOrderByVillageName(villageName);
	}

	public List<VillageList> findBySubdistIdOrderByVillageName(String subdistId) {
		return villageRepo.findBySubdistIdOrderByVillageName(subdistId);
	}

	
}
