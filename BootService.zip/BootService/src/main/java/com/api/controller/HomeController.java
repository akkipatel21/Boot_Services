package com.api.controller;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.api.ApiCall;
import com.api.model.Login;
import com.api.model.NationalDistrict;
import com.api.model.NationalTaluka;
import com.api.model.StateBound;
import com.api.model.VillageList;
import com.api.repo.LoginRepo;
import com.api.services.LoginService;
import com.api.services.NationalDistrictService;
import com.api.services.NationalTalukaService;
import com.api.services.StateBoundService;
import com.api.services.VillageService;
import com.helper.RequestHelper;

@RestController
@EnableWebSecurity
@RequestMapping("/api")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class HomeController {

    @Autowired
    LoginService loginService;
    @Autowired
    LoginRepo loginRepo;
    @Autowired
    StateBoundService stateBoundService;
    @Autowired
    NationalDistrictService nationalDistrictService;
    @Autowired
    NationalTalukaService nationalTalukaService;
    @Autowired
    VillageService villageService;
    @Value("${path.callUrl}")
    private String callUrl;

    @RequestMapping(value = "/Login", method = RequestMethod.POST, produces = "application/json")
    public Map<String, String> authentication(HttpServletRequest request, @RequestBody RequestHelper requestHelper) {
        Map<String, String> response = new HashMap<>();
        try {
            Login login = loginService.findByUserNameAndPassWord(requestHelper.getUserName(), requestHelper.getPassWord());
            if (login != null) {
                String jwt = ApiCall.callAPI(callUrl);
                login.setToken(jwt);
                // loginRepo.save(login);
                Cookie ck = new Cookie("uname", jwt);
                response.put("token", jwt);
            } else {
                response.put("Message", "Invalid Username or Password");
                return response;
            }
            System.out.println("::");
        } catch (Exception e) {
            response.put("Message", e.toString());
            return response;
        }
        return response;
    }

    @RequestMapping("/protected-resource")
    public String protectedResource() {
        return "protected-resource";
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/getStateList", method = RequestMethod.POST, produces = "application/json")
    public @ResponseBody List<StateBound> getStateData(@RequestBody RequestHelper requestHelper) {
        long i = loginRepo.countByToken(requestHelper.getToken());
        if (i != 0) {
            return stateBoundService.findAllByOrderByStname();
        }
        return null;
    }

    @RequestMapping(value = "/getDistrictListByStateId", method = RequestMethod.POST, produces = "application/json")
    public List<NationalDistrict> getDistrictList(@RequestBody RequestHelper requestHelper) {
        long i = loginRepo.countByToken(requestHelper.getToken());
        if (i != 0) {
            return nationalDistrictService.findByStateIdOrderByDistName(requestHelper.getStateId());
        }
        return null;
    }

    @RequestMapping(value = "/getTalukaListByDistId", method = RequestMethod.POST, produces = "application/json")
    public @ResponseBody List<NationalTaluka> getNationalTalukaNames(@RequestBody RequestHelper requestHelper) {
        long i = loginRepo.countByToken(requestHelper.getToken());
        if (i != 0) {
            return nationalTalukaService.findByDistIdOrderBySubdistName(requestHelper.getDistId());
        }
        return null;
    }

    @RequestMapping(value = "/getVillageListBySubdistId", method = RequestMethod.POST, produces = "application/json")
    public List<VillageList> getVillageBySubDistrictId(@RequestBody RequestHelper requestHelper) {

        long i = loginRepo.countByToken(requestHelper.getToken());
        if (i != 0) {
            return villageService.findBySubdistIdOrderByVillageName(requestHelper.getSubdistId());
        }
        return null;
    }

    @RequestMapping(value = "/getVillageListByName", method = RequestMethod.POST, produces = "application/json")
    public List<VillageList> getVillageList(@RequestBody RequestHelper requestHelper) {
        long i = loginRepo.countByToken(requestHelper.getToken());
        if (i != 0) {
            return villageService.findByVillageNameStartingWithIgnoreCaseOrderByVillageName(requestHelper.getVillageName());
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/getState", method = RequestMethod.POST, produces = "application/json")
    public @ResponseBody List<StateBound> getState(@RequestBody RequestHelper requestHelper) {
        return stateBoundService.findAllByOrderByStname();
    }

    // @RequestMapping(value = "/gis",produces = "application/json")
    private String server = "192.168.1.196";
    private int port = 8080;

    @RequestMapping(value = "/gis", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public String mirrorRest(HttpMethod method, HttpServletRequest request, HttpServletResponse response) throws URISyntaxException {

        String req = request.getQueryString()
            .replace("%2C", ",")
            .replace("%3A", ":")
            .replace("%2F", "/")
            .replace("%3D", "=")
            .replace("%5B", "[")
            .replace("%5D", "]")
            .replace("%27", "'")
            .replace("%20", " ")
            .replace("%3C", "<")
            .replace("%3E", ">");

        URI uri = new URI("http", null, server, port, "/geoserver/cite/wms", req, null);

        String body = "";
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> responseEntity = restTemplate.exchange(uri, method, new HttpEntity<String>(body), String.class);

        return responseEntity.getBody();
    }

    /*@RequestMapping("/ows")
    @ResponseBody
    public String mirrorRestOWS(@RequestBody String body, HttpMethod method, HttpServletRequest request,
        HttpServletResponse response) throws URISyntaxException
    {
            
    String req =    request.getQueryString().replace("%2C", ",").replace("%3A", ":").replace("%2F", "/").replace("%27", "'").replace("%20", " ");
            
    
            
        URI uri = new URI("http", null, server, port,"/geoserver/cite/ows",req , null);
    
    
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> responseEntity =
            restTemplate.exchange(uri, method, new HttpEntity<String>(body), String.class);
    
        return responseEntity.getBody();
    }*/
    @RequestMapping(value = "/doPost", method = RequestMethod.POST, produces = "application/json")
    protected String doPost(@RequestBody Abc a, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // String user = request.getParameter("user");
        // String pwd = request.getParameter("pwd");

        String userID = "akash", password = "akash";
        if (userID.equals(a.getPwd()) && password.equals(a.getPwd())) {
            HttpSession session = request.getSession();
            session.setAttribute("user", "Pankaj");
            // setting session to expiry in 30 mins
            session.setMaxInactiveInterval(30 * 60);
            Cookie userName = new Cookie("user", a.getPwd());
            userName.setMaxAge(30 * 60);
            response.addCookie(userName);
            System.out.println("::hiiiii::");
//            Cookie[] cookies = request.getCookies();
//            for (Cookie cookie : cookies) {
//                if (cookie.getName().equals("user")) {
//                    if (cookie.getValue().equals(a.getPwd())) {
//                        System.out.println("iiiii");
//                        return cookie.getValue();
//                    }
//                }
//                System.out.println("****" + cookie.getValue());
//            }
//            Cookie cookie = new Cookie("name", "value");
//            response.addCookie(cookie);
            // Cookie thecookie = new Cookie("thecookie", loc);
            // thecookie.setMaxAge(60*60*24);
        } 
        return null;
    }

    
    
    
    
    @RequestMapping(value = "/boom", method = RequestMethod.POST)
    protected String boom(@RequestBody Abc a, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    Cookie[] cookies = request.getCookies();
    for (Cookie cookie : cookies) {
        if (cookie.getName().equals("user")) {
            if (cookie.getValue().equals(a.getPwd())) {
                System.out.println("iiiii");
                return cookie.getValue();
            }
        }
        System.out.println("****" + cookie.getValue());
    }
    return null;
    }
    
    
}
