package com.api.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.api.model.NdrfGeom;
import com.api.services.NdrfService;

@RestController
@EnableWebSecurity
@RequestMapping("/api")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class NdrfController {
	@Autowired
	NdrfService ndrfService;
	
	@RequestMapping(value = "/SaveGeomNDRF", method = RequestMethod.POST)
	public String SaveGeomNDRF(@RequestBody NdrfGeom ndrfGeo) {
		NdrfGeom ndrfGeom = new NdrfGeom();
		ndrfGeom.setSt_id(ndrfGeo.getSt_id());
		ndrfGeom.setstateName(ndrfGeo.getstateName());
		ndrfGeom.setDist_id(ndrfGeo.getDist_id());
		ndrfGeom.setDistrictName(ndrfGeo.getDistrictName());
		ndrfGeom.setTal_id(ndrfGeo.getTal_id());
		ndrfGeom.setTalukaName(ndrfGeo.getTalukaName());
		ndrfGeom.setVill_id(ndrfGeo.getVill_id());
		ndrfGeom.setVillageName(ndrfGeo.getVillageName());
		ndrfGeom.setLatitude_d(ndrfGeo.getLatitude_d());
		ndrfGeom.setLongitude_d(ndrfGeo.getLongitude_d());
		ndrfGeom.setInc_st_date(ndrfGeo.getInc_st_date());
		ndrfGeom.setInc_details(ndrfGeo.getInc_details());
		ndrfGeom.setInc_st_time(ndrfGeo.getInc_st_time());
		ndrfGeom.setReporter_name(ndrfGeo.getReporter_name());
		ndrfGeom.setReporter_mblnum(ndrfGeo.getReporter_mblnum());
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String changeDate= formatter.format(date);
		ndrfGeom.setCreatedDate(changeDate);
		ndrfService.save(ndrfGeom);
		return "{\"message\":\"Data Saved Successfully!\"}";
	}

	@RequestMapping(value = "/ndrfIncidentReport", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody List<NdrfGeom> ndrfIncidentReport() {
		return ndrfService.findAll();
	}
	
}
